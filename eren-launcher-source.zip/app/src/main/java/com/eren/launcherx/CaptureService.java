package com.eren.launcherx;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

/** mediaProjection 前台服务（必须是顶层类，清单才能按 .CaptureService 找到）。 */
public class CaptureService extends Service {
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String id = "eren_capture";
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(id, "屏幕采集", NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(ch);
        }
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, id)
                : new Notification.Builder(this);
        b.setContentTitle("恶認助手").setContentText("正在进行屏幕采集")
                .setSmallIcon(android.R.drawable.ic_menu_camera).setOngoing(true);
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1001, b.build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(1001, b.build());
        }
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
