package com.eren.launcherx;

import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** 悬浮助手 v5：挂边 + 九宫格 + 三档调度 + shell 帧率 */
public class AssistantUI {

    private final MainActivity act;
    private final WindowManager wm;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final int tabW, tabH;

    private View tab;
    private LinearLayout panel;
    private LinearLayout cardBody;
    private WindowManager.LayoutParams tabLp;

    private boolean showing = false;
    private boolean expanded = false;
    private int page = 1;

    private boolean recording = false;
    private Runnable stopRecorder;

    private FxView fxView;
    private int fxMode = 0;
    private View dimView;
    private View guardView;
    private boolean guardOn = false;

    private boolean hzOn = false;
    private TextView hzOverlay;
    private Thread hzThread;
    private String prevGovernor = "";

    private static final String[] FILTERS = {"原色", "暖色", "冷色", "夜视", "漫画", "老电视"};

    AssistantUI(MainActivity a) {
        act = a;
        wm = (WindowManager) a.getSystemService(Context.WINDOW_SERVICE);
        tabW = dp(26);
        tabH = dp(74);
    }

    boolean isShowing() {
        return showing;
    }

    private int dp(float v) {
        return (int) (v * act.getResources().getDisplayMetrics().density + 0.5f);
    }

    private int overlayType() {
        return Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    /* ============ 挂边 ============ */

    void show() {
        if (showing) {
            return;
        }
        TextView t = new TextView(act);
        t.setText("◀");
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        t.setTextColor(0xCCE8FBFF);
        t.setGravity(Gravity.CENTER);
        t.setBackgroundDrawable(tabBg(true));
        tab = t;

        tabLp = new WindowManager.LayoutParams(tabW, tabH, overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        tabLp.gravity = Gravity.TOP | Gravity.LEFT;
        DisplayMetrics dm = act.getResources().getDisplayMetrics();
        tabLp.x = dm.widthPixels - tabW;
        tabLp.y = dm.heightPixels / 2;

        tab.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int startX, startY;
            boolean moved;

            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX();
                        downY = e.getRawY();
                        startX = tabLp.x;
                        startY = tabLp.y;
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int) (e.getRawX() - downX);
                        int dy = (int) (e.getRawY() - downY);
                        if (Math.abs(dx) > dp(8) || Math.abs(dy) > dp(8)) {
                            moved = true;
                        }
                        tabLp.x = startX + dx;
                        tabLp.y = startY + dy;
                        try {
                            wm.updateViewLayout(tab, tabLp);
                        } catch (Exception ignored) {
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (moved) {
                            snapToEdge();
                        } else {
                            togglePanel();
                        }
                        return true;
                }
                return false;
            }
        });

        try {
            wm.addView(tab, tabLp);
            showing = true;
        } catch (Exception e) {
            showing = false;
            Toast.makeText(act, "悬浮窗加不上", Toast.LENGTH_LONG).show();
        }
    }

    private GradientDrawable tabBg(boolean right) {
        float r = tabW;
        float[] radii = right
                ? new float[]{r, r, 0, 0, 0, 0, r, r}
                : new float[]{0, 0, r, r, r, r, 0, 0};
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0x990B1020);
        bg.setCornerRadii(radii);
        bg.setStroke(dp(1), 0xAA29E7FF);
        return bg;
    }

    private void snapToEdge() {
        DisplayMetrics dm = act.getResources().getDisplayMetrics();
        int w = dm.widthPixels, h = dm.heightPixels;
        boolean right = tabLp.x + tabW / 2 >= w / 2;
        tabLp.x = right ? w - tabW : 0;
        ((TextView) tab).setText(right ? "◀" : "▶");
        tab.setBackgroundDrawable(tabBg(right));
        if (tabLp.y < 0) {
            tabLp.y = 0;
        }
        if (tabLp.y > h - tabH) {
            tabLp.y = h - tabH;
        }
        try {
            wm.updateViewLayout(tab, tabLp);
        } catch (Exception ignored) {
        }
        if (expanded) {
            closePanel();
        }
    }

    void hide() {
        closePanel();
        stopHz();
        removeFx();
        removeDim();
        removeGuard();
        if (tab != null) {
            try {
                wm.removeView(tab);
            } catch (Exception ignored) {
            }
            tab = null;
        }
        showing = false;
    }

    /* ============ 面板 ============ */

    private void togglePanel() {
        if (expanded) {
            closePanel();
        } else {
            openPanel();
        }
    }

    private void closePanel() {
        try {
            if (panel != null) {
                wm.removeView(panel);
            }
        } catch (Exception ignored) {
        }
        panel = null;
        expanded = false;
    }

    private void openPanel() {
        if (panel != null) {
            return;
        }
        DisplayMetrics dm = act.getResources().getDisplayMetrics();
        int railW = dp(48);
        int panelW = Math.min(dp(316), (int) (Math.min(dm.widthPixels, dm.heightPixels) * 0.92f));
        int panelH = Math.min(dp(360), (int) (dm.heightPixels * 0.62f));
        int cardW = panelW - railW - dp(6);

        panel = new LinearLayout(act);
        panel.setOrientation(LinearLayout.HORIZONTAL);

        LinearLayout rail = new LinearLayout(act);
        rail.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable railBg = new GradientDrawable();
        railBg.setCornerRadius(dp(22));
        railBg.setColor(0xE60D1119);
        rail.setBackgroundDrawable(railBg);
        rail.setPadding(dp(4), dp(10), dp(4), dp(8));
        rail.addView(railItem("◉", "性能", 0));
        rail.addView(railItem("▦", "工具", 1));
        rail.addView(railItem("☰", "我的", 2));
        View spacer = new View(act);
        rail.addView(spacer, new LinearLayout.LayoutParams(1, 0, 1f));
        rail.addView(railClose());
        panel.addView(rail, new LinearLayout.LayoutParams(railW, panelH));

        LinearLayout card = new LinearLayout(act);
        card.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setCornerRadius(dp(20));
        cardBg.setColor(0xE6111620);
        card.setBackgroundDrawable(cardBg);
        card.setPadding(dp(10), dp(10), dp(10), dp(10));

        cardBody = new LinearLayout(act);
        cardBody.setOrientation(LinearLayout.VERTICAL);
        card.addView(cardBody, new LinearLayout.LayoutParams(-1, -1));

        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(cardW, panelH);
        cardLp.leftMargin = dp(6);
        panel.addView(card, cardLp);

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(panelW, panelH, overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.LEFT;
        boolean rightSide = tabLp.x + tabW / 2 >= dm.widthPixels / 2;
        lp.x = rightSide ? dm.widthPixels - panelW - dp(2) : dp(2);
        lp.y = Math.max(0, Math.min(tabLp.y - dp(70), dm.heightPixels - panelH - dp(10)));

        try {
            renderPage();
            wm.addView(panel, lp);
            expanded = true;
        } catch (Exception e) {
            panel = null;
            expanded = false;
        }
    }

    private View railItem(String icon, String label, final int idx) {
        LinearLayout box = new LinearLayout(act);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(0, dp(7), 0, dp(7));

        TextView ic = new TextView(act);
        ic.setText(icon);
        ic.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        ic.setGravity(Gravity.CENTER);
        box.addView(ic, new LinearLayout.LayoutParams(-1, -2));

        TextView lb = new TextView(act);
        lb.setText(label);
        lb.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        lb.setGravity(Gravity.CENTER);
        box.addView(lb, new LinearLayout.LayoutParams(-1, -2));

        box.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                page = idx;
                renderPage();
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(6);
        box.setLayoutParams(lp);
        return box;
    }

    private View railClose() {
        LinearLayout box = new LinearLayout(act);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(0, dp(6), 0, dp(6));
        TextView ic = new TextView(act);
        ic.setText("⇤");
        ic.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        ic.setTextColor(0xFFFFC49A);
        ic.setGravity(Gravity.CENTER);
        box.addView(ic, new LinearLayout.LayoutParams(-1, -2));
        TextView lb = new TextView(act);
        lb.setText("收起");
        lb.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9);
        lb.setTextColor(0xCCFFC49A);
        lb.setGravity(Gravity.CENTER);
        box.addView(lb, new LinearLayout.LayoutParams(-1, -2));
        box.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                closePanel();
            }
        });
        return box;
    }

    private void renderPage() {
        if (cardBody == null) {
            return;
        }
        cardBody.removeAllViews();
        if (page == 0) {
            renderPerf();
        } else if (page == 1) {
            renderTools();
        } else {
            renderMine();
        }
        if (panel != null && panel.getChildCount() > 0) {
            LinearLayout rail = (LinearLayout) panel.getChildAt(0);
            for (int i = 0; i < 3 && i < rail.getChildCount(); i++) {
                View item = rail.getChildAt(i);
                if (item instanceof LinearLayout) {
                    LinearLayout box = (LinearLayout) item;
                    boolean on = i == page;
                    ((TextView) box.getChildAt(0)).setTextColor(on ? 0xFFFF8A3D : 0x99FFFFFF);
                    ((TextView) box.getChildAt(1)).setTextColor(on ? 0xFFFF8A3D : 0x77FFFFFF);
                }
            }
        }
    }

    /* ---- 工具页 ---- */

    private void renderTools() {
        cardBody.addView(statsRow());

        SeekBar bar = new SeekBar(act);
        bar.setMax(100);
        bar.setProgress(75);
        cardBody.addView(bar, new LinearLayout.LayoutParams(-1, dp(26)));
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                setDim((100 - p) * 2);
            }

            public void onStartTrackingTouch(SeekBar sb) {
            }

            public void onStopTrackingTouch(SeekBar sb) {
            }
        });

        HorizontalScrollView hs = new HorizontalScrollView(act);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout strip = new LinearLayout(act);
        strip.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < FILTERS.length; i++) {
            strip.addView(filterChip(i));
        }
        hs.addView(strip);
        cardBody.addView(hs, new LinearLayout.LayoutParams(-1, dp(30)));

        GridLayout grid = new GridLayout(act);
        grid.setColumnCount(3);
        grid.setRowCount(4);
        grid.setPadding(0, dp(4), 0, 0);

        grid.addView(tile("▣", "游戏收纳", false, new Runnable() {
            public void run() {
                toast("在主页顶部图标切换游戏");
            }
        }));
        grid.addView(tile("☾", "免打扰", dndOn(), new Runnable() {
            public void run() {
                toggleDnd();
            }
        }));
        grid.addView(tile("◎", "网络优化", false, new Runnable() {
            public void run() {
                optimizeNet();
            }
        }));
        grid.addView(tile("▤", "弹幕通知", false, new Runnable() {
            public void run() {
                toast("弹幕通知需要通知使用权，先到设置里授权");
            }
        }));
        grid.addView(tile("✦", "清理加速", false, new Runnable() {
            public void run() {
                clearCache();
            }
        }));
        grid.addView(tile("✂", "截屏", false, new Runnable() {
            public void run() {
                closePanel();
                act.requestProjection(1);
            }
        }));
        grid.addView(tile("◉", recording ? "停止" : "录屏", recording, new Runnable() {
            public void run() {
                if (recording) {
                    if (stopRecorder != null) {
                        stopRecorder.run();
                    }
                    recording = false;
                    stopRecorder = null;
                    renderPage();
                } else {
                    closePanel();
                    act.requestProjection(2);
                }
            }
        }));
        grid.addView(tile("⟳", "帧率", hzOn, new Runnable() {
            public void run() {
                toggleHz(!hzOn);
                renderPage();
            }
        }));
        grid.addView(tile("⊞", "滤镜", fxMode > 0, new Runnable() {
            public void run() {
                setFilter((fxMode + 1) % FILTERS.length);
                renderPage();
            }
        }));
        grid.addView(tile("❖", "防误触", guardOn, new Runnable() {
            public void run() {
                toggleGuard(!guardOn);
                renderPage();
            }
        }));

        cardBody.addView(grid, new LinearLayout.LayoutParams(-1, 0, 1f));
    }

    private View filterChip(final int idx) {
        final TextView c = new TextView(act);
        c.setText(FILTERS[idx]);
        c.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        c.setGravity(Gravity.CENTER);
        c.setPadding(dp(10), dp(3), dp(10), dp(3));
        boolean on = idx == fxMode;
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(12));
        g.setColor(on ? 0xFF29E7FF : 0x14FFFFFF);
        c.setBackgroundDrawable(g);
        c.setTextColor(on ? 0xFF04121A : 0xCCFFFFFF);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(24));
        lp.rightMargin = dp(6);
        c.setLayoutParams(lp);
        c.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                setFilter(idx);
                renderPage();
            }
        });
        return c;
    }

    private View statsRow() {
        LinearLayout row = new LinearLayout(act);
        row.setOrientation(LinearLayout.HORIZONTAL);

        TextView net = new TextView(act);
        net.setText("网络 -- ms");
        net.setTextColor(0x99FFFFFF);
        net.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);

        TextView hz = new TextView(act);
        hz.setText("刷新率 " + Math.round(refreshRate()) + " Hz");
        hz.setTextColor(0x99FFFFFF);
        hz.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);

        TextView bat = new TextView(act);
        bat.setText("电量 " + batteryLevel() + " %");
        bat.setTextColor(0x99FFFFFF);
        bat.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);

        row.addView(net, new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(hz, new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(bat, new LinearLayout.LayoutParams(0, -2, 1f));

        measurePing(net);
        return row;
    }

    private float refreshRate() {
        try {
            return wm.getDefaultDisplay().getRefreshRate();
        } catch (Exception e) {
            return 60f;
        }
    }

    private void measurePing(final TextView out) {
        new Thread(new Runnable() {
            public void run() {
                long ms = -1;
                try {
                    long t0 = System.currentTimeMillis();
                    Socket s = new Socket();
                    s.connect(new InetSocketAddress("223.5.5.5", 80), 2000);
                    ms = System.currentTimeMillis() - t0;
                    s.close();
                } catch (Exception ignored) {
                }
                final long v = ms;
                ui.post(new Runnable() {
                    public void run() {
                        out.setText(v < 0 ? "网络 -- ms" : "网络 " + v + " ms");
                    }
                });
            }
        }).start();
    }

    private int batteryLevel() {
        try {
            BatteryManager bm = (BatteryManager) act.getSystemService(Context.BATTERY_SERVICE);
            if (bm != null) {
                return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
            }
        } catch (Exception ignored) {
        }
        return 0;
    }

    private View tile(String icon, String label, boolean active, final Runnable action) {
        LinearLayout box = new LinearLayout(act);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(12));
        g.setColor(active ? 0x5538E1FF : 0x14FFFFFF);
        if (active) {
            g.setStroke(dp(1) + 1, 0xFF29E7FF);
        }
        box.setBackgroundDrawable(g);

        TextView ic = new TextView(act);
        ic.setText(icon);
        ic.setTextColor(active ? 0xFF29E7FF : 0xFFE8FBFF);
        ic.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        ic.setGravity(Gravity.CENTER);
        box.addView(ic, new LinearLayout.LayoutParams(-1, -2));

        TextView lb = new TextView(act);
        lb.setText(label);
        lb.setTextColor(active ? 0xFF29E7FF : 0xCCFFFFFF);
        lb.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9);
        lb.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(-1, -2);
        llp.topMargin = dp(3);
        box.addView(lb, llp);

        box.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                action.run();
            }
        });

        GridLayout.LayoutParams lp = new GridLayout.LayoutParams(
                GridLayout.spec(GridLayout.UNDEFINED, 1f),
                GridLayout.spec(GridLayout.UNDEFINED, 1f));
        lp.width = 0;
        lp.height = dp(58);
        lp.setMargins(dp(3), dp(3), dp(3), dp(3));
        box.setLayoutParams(lp);
        return box;
    }

    /* ---- 性能页 ---- */

    private void renderPerf() {
        TextView head = new TextView(act);
        head.setText("HYPERBOOST");
        head.setTextColor(0x66FFFFFF);
        head.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9);
        head.setGravity(Gravity.CENTER);
        cardBody.addView(head, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout row = new LinearLayout(act);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(6), 0, 0);
        ArcGauge gCpu = new ArcGauge(act);
        gCpu.set(String.valueOf(cpuUsage()), "% CPU", cpuUsage() / 100f);
        ArcGauge gBat = new ArcGauge(act);
        gBat.set(String.valueOf(batteryLevel()), "%", batteryLevel() / 100f);
        ArcGauge gNet = new ArcGauge(act);
        gNet.set("--", "ms", 0f);
        row.addView(gCpu, new LinearLayout.LayoutParams(0, dp(86), 1f));
        row.addView(gBat, new LinearLayout.LayoutParams(0, dp(86), 1f));
        row.addView(gNet, new LinearLayout.LayoutParams(0, dp(86), 1f));
        cardBody.addView(row, new LinearLayout.LayoutParams(-1, -2));

        cardBody.addView(chips("节能模式", "均衡模式", "电竞模式"));
        cardBody.addView(hintLine("三档都会写 cpufreq，需要 root / Shizuku 授权"));
        measurePingGauge(gNet);
    }

    private void measurePingGauge(final ArcGauge g) {
        new Thread(new Runnable() {
            public void run() {
                long ms = -1;
                try {
                    long t0 = System.currentTimeMillis();
                    Socket s = new Socket();
                    s.connect(new InetSocketAddress("223.5.5.5", 80), 2000);
                    ms = System.currentTimeMillis() - t0;
                    s.close();
                } catch (Exception ignored) {
                }
                final long v = ms;
                ui.post(new Runnable() {
                    public void run() {
                        g.set(v < 0 ? "—" : String.valueOf(v), "ms", v < 0 ? 0f : Math.min(1f, v / 200f));
                    }
                });
            }
        }).start();
    }

    private View chips(String... names) {
        LinearLayout row = new LinearLayout(act);
        row.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < names.length; i++) {
            final TextView c = new TextView(act);
            c.setText(names[i]);
            c.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9);
            c.setGravity(Gravity.CENTER);
            c.setPadding(dp(6), dp(6), dp(6), dp(6));
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(dp(14));
            g.setColor(0x14FFFFFF);
            c.setBackgroundDrawable(g);
            c.setTextColor(0x99FFFFFF);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            lp.rightMargin = i < names.length - 1 ? dp(5) : 0;
            row.addView(c, lp);
            c.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    String label = ((TextView) v).getText().toString();
                    if ("节能模式".equals(label)) {
                        applyProfile("powersave");
                    } else if ("均衡模式".equals(label)) {
                        applyProfile("schedutil");
                    } else {
                        applyProfile("performance");
                    }
                    LinearLayout parent = (LinearLayout) v.getParent();
                    for (int k = 0; k < parent.getChildCount(); k++) {
                        View sib = parent.getChildAt(k);
                        if (sib instanceof TextView) {
                            boolean sel = sib == v;
                            GradientDrawable gg = new GradientDrawable();
                            gg.setCornerRadius(dp(14));
                            gg.setColor(sel ? 0x33FF8A3D : 0x14FFFFFF);
                            sib.setBackgroundDrawable(gg);
                            ((TextView) sib).setTextColor(sel ? 0xFFFFC49A : 0x99FFFFFF);
                        }
                    }
                }
            });
        }
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(-1, -2);
        rlp.topMargin = dp(8);
        row.setLayoutParams(rlp);
        return row;
    }

    private View hintLine(String text) {
        TextView tv = new TextView(act);
        tv.setText(text);
        tv.setTextColor(0x66FFFFFF);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(6);
        tv.setLayoutParams(lp);
        return tv;
    }

    /* ---- 我的页 ---- */

    private void renderMine() {
        TextView name = new TextView(act);
        name.setText("恶認游戏启动器");
        name.setTextColor(0xFFE8FBFF);
        name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        cardBody.addView(name);

        TextView ver = new TextView(act);
        ver.setText("v" + MainActivity.APP_VERSION + " · 本地构建");
        ver.setTextColor(0x77FFFFFF);
        ver.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        LinearLayout.LayoutParams vlp = new LinearLayout.LayoutParams(-1, -2);
        vlp.topMargin = dp(6);
        cardBody.addView(ver, vlp);

        TextView sh = new TextView(act);
        sh.setText("查看调度状态（root）");
        sh.setGravity(Gravity.CENTER);
        sh.setTextColor(0xFF8FE9FF);
        sh.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        sh.setPadding(0, dp(8), 0, dp(8));
        GradientDrawable g1 = new GradientDrawable();
        g1.setCornerRadius(dp(10));
        g1.setColor(0x1A29E7FF);
        sh.setBackgroundDrawable(g1);
        LinearLayout.LayoutParams l1 = new LinearLayout.LayoutParams(-1, -2);
        l1.topMargin = dp(10);
        cardBody.addView(sh, l1);
        sh.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                act.runShellScript("status");
            }
        });

        View sp = new View(act);
        cardBody.addView(sp, new LinearLayout.LayoutParams(1, 0, 1f));

        TextView close = new TextView(act);
        close.setText("彻底关闭悬浮助手");
        close.setGravity(Gravity.CENTER);
        close.setTextColor(0xFFFFC49A);
        close.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        close.setPadding(0, dp(10), 0, dp(10));
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(12));
        g.setColor(0x33FF8A3D);
        close.setBackgroundDrawable(g);
        close.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                hide();
                act.updateButtons();
            }
        });
        cardBody.addView(close, new LinearLayout.LayoutParams(-1, -2));
    }

    /* ============ 调度 ============ */

    private void applyProfile(final String gov) {
        new Thread(new Runnable() {
            public void run() {
                if (!RootUtil.available()) {
                    toastSafe("需要 root 或 Shizuku 授权才能改调度");
                    return;
                }
                doApplyProfile(gov);
            }
        }).start();
    }

    private void toastSafe(final String s) {
        ui.post(new Runnable() {
            public void run() {
                Toast.makeText(act, s, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void doApplyProfile(String gov) {
        if (prevGovernor == null || prevGovernor.length() == 0) {
            prevGovernor = RootUtil.run("cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor");
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 8; i++) {
            sb.append("echo ").append(gov)
                    .append(" > /sys/devices/system/cpu/cpu").append(i)
                    .append("/cpufreq/scaling_governor 2>/dev/null; ");
        }
        RootUtil.run(sb.toString());
        toastSafe("调度已切到 " + gov);
    }

    /* ============ 帧率（shell） ============ */

    private void toggleHz(boolean on) {
        hzOn = on;
        if (!on) {
            stopHz();
            return;
        }
        if (!RootUtil.available()) {
            hzOn = false;
            toast("帧率需要 root 或 Shizuku 授权");
            return;
        }
        TextView tv = new TextView(act);
        tv.setTextColor(0xFFFFD740);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        tv.setPadding(dp(6), dp(2), dp(6), dp(2));
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(6));
        g.setColor(0x99000000);
        tv.setBackgroundDrawable(g);
        tv.setText("帧率 --");
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                -2, -2, overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.LEFT;
        lp.x = dp(14);
        lp.y = dp(96);
        try {
            wm.addView(tv, lp);
            hzOverlay = tv;
        } catch (Exception e) {
            toast("帧率浮层加不上");
            return;
        }
        hzThread = new Thread(new Runnable() {
            public void run() {
                while (hzOn) {
                    final int fps = readFpsFromShell();
                    ui.post(new Runnable() {
                        public void run() {
                            if (hzOverlay != null) {
                                String txt;
                                if (fps > 0) {
                                    txt = "帧率 " + fps + " fps";
                                } else if (fps == -2) {
                                    txt = "帧率 -- 无图层(" + lastDiag + ")";
                                } else if (fps == -3) {
                                    txt = "帧率 -- 无输出(" + lastDiag + ")";
                                } else {
                                    txt = "帧率 -- 无帧数据";
                                }
                                hzOverlay.setText(txt);
                            }
                        }
                    });
                    try {
                        Thread.sleep(1000);
                    } catch (Exception ignored) {
                    }
                }
            }
        });
        hzThread.start();
    }

    private String lastDiag = "";

    /** 逐个图层试 latency，取帧数最多的那个。 */
    private int readFpsFromShell() {
        try {
            String list = RootUtil.run("dumpsys SurfaceFlinger --list");
            if (list == null || list.trim().length() == 0) {
                lastDiag = "list空";
                return -3;
            }
            java.util.List<String> cands = new java.util.ArrayList<String>();
            for (String l : list.split("\n")) {
                String s = l.trim();
                if (s.length() == 0) {
                    continue;
                }
                if (s.contains("SurfaceView")) {
                    cands.add(s);
                }
            }
            if (cands.isEmpty()) {
                for (String l : list.split("\n")) {
                    String s = l.trim();
                    if (s.length() > 0) {
                        cands.add(s);
                    }
                }
            }
            lastDiag = "图层" + cands.size();
            int best = -1;
            int tried = 0;
            for (String layer : cands) {
                if (tried++ >= 8) {
                    break;
                }
                String out = RootUtil.run("dumpsys SurfaceFlinger --latency '" + layer + "'");
                if (out == null) {
                    continue;
                }
                long maxTs = 0;
                java.util.List<Long> stamps = new java.util.ArrayList<Long>();
                for (String line : out.split("\n")) {
                    String[] p = line.trim().split("\\s+");
                    if (p.length != 3) {
                        continue;
                    }
                    try {
                        long ts = Long.parseLong(p[1]);
                        if (ts > 0 && ts != Long.MAX_VALUE) {
                            if (ts > maxTs) {
                                maxTs = ts;
                            }
                            stamps.add(ts);
                        }
                    } catch (Exception ignored) {
                    }
                }
                if (maxTs == 0) {
                    continue;
                }
                int c = 0;
                long floor = maxTs - 1000000000L;
                for (Long ts : stamps) {
                    if (ts >= floor) {
                        c++;
                    }
                }
                if (c > best) {
                    best = c;
                }
            }
            if (best > 0) {
                return best;
            }
            return -1;
        } catch (Exception e) {
            lastDiag = e.getClass().getSimpleName();
            return -3;
        }
    }

    private void stopHz() {
        hzOn = false;
        if (hzOverlay != null) {
            try {
                wm.removeView(hzOverlay);
            } catch (Exception ignored) {
            }
            hzOverlay = null;
        }
        hzThread = null;
    }

    private int cpuUsage() {
        try {
            BufferedReader br = new BufferedReader(new java.io.FileReader("/proc/stat"));
            String line = br.readLine();
            br.close();
            if (line == null) {
                return 0;
            }
            String[] p = line.trim().split("\\s+");
            long total = 0;
            for (int i = 1; i < p.length && i <= 8; i++) {
                total += Long.parseLong(p[i]);
            }
            long idle = Long.parseLong(p[4]);
            long dt = total - lastTotal;
            long di = idle - lastIdle;
            lastTotal = total;
            lastIdle = idle;
            if (dt <= 0) {
                return 0;
            }
            return (int) Math.max(0, Math.min(100, (dt - di) * 100 / dt));
        } catch (Exception e) {
            return 0;
        }
    }

    private long lastTotal = 0L, lastIdle = 0L;

    /* ============ 录制 / 滤镜 / 亮度 / 防误触 ============ */

    void setRecording(boolean on, Runnable stop) {
        recording = on;
        stopRecorder = stop;
        if (expanded) {
            renderPage();
        }
    }

    private void setFilter(int mode) {
        fxMode = mode;
        if (mode == 0) {
            removeFx();
            return;
        }
        if (fxView == null) {
            fxView = new FxView(act);
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(-1, -1, overlayType(),
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            try {
                wm.addView(fxView, lp);
            } catch (Exception e) {
                fxView = null;
                return;
            }
        }
        fxView.setMode(mode);
        toast("滤镜：" + FILTERS[mode]);
    }

    private void removeFx() {
        if (fxView != null) {
            try {
                wm.removeView(fxView);
            } catch (Exception ignored) {
            }
            fxView = null;
        }
    }

    private void setDim(int alpha) {
        if (alpha <= 0) {
            removeDim();
            return;
        }
        if (dimView == null) {
            dimView = new View(act);
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(-1, -1, overlayType(),
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            try {
                wm.addView(dimView, lp);
            } catch (Exception e) {
                dimView = null;
                return;
            }
        }
        dimView.setBackgroundColor(Math.min(190, alpha) << 24);
    }

    private void removeDim() {
        if (dimView != null) {
            try {
                wm.removeView(dimView);
            } catch (Exception ignored) {
            }
            dimView = null;
        }
    }

    private String prevNavMode = "";

    /** 防误触：关掉边缘返回手势（切三键导航），root 下才能真正生效。 */
    private void toggleGuard(boolean on) {
        guardOn = on;
        if (!on) {
            restoreNav();
            removeGuard();
            toast("防误触已关，导航已还原");
            return;
        }
        new Thread(new Runnable() {
            public void run() {
                if (RootUtil.available()) {
                    prevNavMode = RootUtil.run("settings get secure navigation_mode");
                    RootUtil.run("settings put secure navigation_mode 0");
                    toastSafe("防误触已开：边缘返回手势已关闭（三键导航）");
                } else {
                    toastSafe("防误触需要 root 或 Shizuku，普通应用拦不住系统手势");
                }
            }
        }).start();
    }

    private void restoreNav() {
        final String prev = prevNavMode;
        if (prev == null || prev.length() == 0 || "null".equals(prev)) {
            return;
        }
        new Thread(new Runnable() {
            public void run() {
                RootUtil.run("settings put secure navigation_mode " + prev.trim());
            }
        }).start();
    }

    private void removeGuard() {
        if (guardView != null) {
            try {
                wm.removeView(guardView);
            } catch (Exception ignored) {
            }
            guardView = null;
        }
        guardOn = false;
    }

    /* ============ 免打扰 / 网络 / 清理 ============ */

    private boolean dndOn() {
        try {
            NotificationManager nm = (NotificationManager) act.getSystemService(Context.NOTIFICATION_SERVICE);
            return nm != null && nm.getCurrentInterruptionFilter() != NotificationManager.INTERRUPTION_FILTER_ALL;
        } catch (Exception e) {
            return false;
        }
    }

    private void toggleDnd() {
        NotificationManager nm = (NotificationManager) act.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) {
            return;
        }
        if (!nm.isNotificationPolicyAccessGranted()) {
            toast("先授予勿扰访问权限");
            try {
                act.startActivity(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            } catch (Exception ignored) {
            }
            return;
        }
        boolean on = dndOn();
        nm.setInterruptionFilter(on ? NotificationManager.INTERRUPTION_FILTER_ALL
                : NotificationManager.INTERRUPTION_FILTER_PRIORITY);
        toast(on ? "免打扰已关" : "免打扰已开");
        renderPage();
    }

    private void optimizeNet() {
        toast("正在测延迟…");
        new Thread(new Runnable() {
            public void run() {
                String[] hosts = {"223.5.5.5", "119.29.29.29", "114.114.114.114"};
                long best = Long.MAX_VALUE;
                String bh = "";
                for (String h : hosts) {
                    try {
                        long t0 = System.currentTimeMillis();
                        Socket s = new Socket();
                        s.connect(new InetSocketAddress(h, 80), 1200);
                        long ms = System.currentTimeMillis() - t0;
                        s.close();
                        if (ms < best) {
                            best = ms;
                            bh = h;
                        }
                    } catch (Exception ignored) {
                    }
                }
                final long b = best;
                final String host = bh;
                ui.post(new Runnable() {
                    public void run() {
                        toast(b == Long.MAX_VALUE ? "网络不通" : ("最优 " + host + "，" + b + " ms"));
                    }
                });
            }
        }).start();
    }

    private void clearCache() {
        long freed = 0;
        try {
            freed = deleteDir(act.getCacheDir());
        } catch (Exception ignored) {
        }
        System.gc();
        toast("已清理 " + (freed / 1024) + " KB 缓存");
    }

    private long deleteDir(java.io.File dir) {
        if (dir == null || !dir.exists()) {
            return 0;
        }
        long sum = 0;
        java.io.File[] fs = dir.listFiles();
        if (fs == null) {
            return 0;
        }
        for (java.io.File f : fs) {
            if (f.isDirectory()) {
                sum += deleteDir(f);
            } else {
                sum += f.length();
                f.delete();
            }
        }
        return sum;
    }

    private void toast(String s) {
        Toast.makeText(act, s, Toast.LENGTH_SHORT).show();
    }

    /* ============ 自绘 ============ */

    static class FxView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private int mode = 0;

        FxView(Context c) {
            super(c);
        }

        void setMode(int m) {
            mode = m;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            int w = getWidth(), h = getHeight();
            switch (mode) {
                case 1:
                    canvas.drawColor(0x2AFF7A00);
                    break;
                case 2:
                    canvas.drawColor(0x262E7BFF);
                    break;
                case 3:
                    canvas.drawColor(0x3300FF66);
                    break;
                case 4:
                    canvas.drawColor(0x1AFFFFFF);
                    p.setColor(0x33000000);
                    for (int y = 0; y < h; y += 14) {
                        for (int x = 0; x < w; x += 14) {
                            canvas.drawCircle(x, y, 2.2f, p);
                        }
                    }
                    break;
                case 5:
                    p.setColor(0x33000000);
                    for (int y = 0; y < h; y += 4) {
                        canvas.drawRect(0, y, w, y + 2, p);
                    }
                    break;
                default:
                    break;
            }
        }
    }

    static class ArcGauge extends View {
        private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fg = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint tx = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint un = new Paint(Paint.ANTI_ALIAS_FLAG);
        private String value = "--";
        private String unit = "";
        private float pct = 0f;

        ArcGauge(Context c) {
            super(c);
            bg.setStyle(Paint.Style.STROKE);
            bg.setStrokeWidth(dp(4));
            bg.setColor(0x22FFFFFF);
            fg.setStyle(Paint.Style.STROKE);
            fg.setStrokeWidth(dp(4));
            fg.setColor(0xFFFF8A3D);
            tx.setColor(0xFFFFFFFF);
            tx.setTextAlign(Paint.Align.CENTER);
            tx.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
            un.setColor(0x88FFFFFF);
            un.setTextAlign(Paint.Align.CENTER);
        }

        private float dp(float v) {
            return v * getResources().getDisplayMetrics().density;
        }

        void set(String v, String u, float p) {
            value = v;
            unit = u;
            pct = Math.max(0f, Math.min(1f, p));
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float w = getWidth(), h = getHeight();
            float r = Math.min(w, h) / 2f - dp(6);
            float cx = w / 2f, cy = h / 2f;
            RectF oval = new RectF(cx - r, cy - r, cx + r, cy + r);
            canvas.drawArc(oval, 135f, 270f, false, bg);
            canvas.drawArc(oval, 135f, 270f * pct, false, fg);
            tx.setTextSize(dp(13));
            un.setTextSize(dp(8));
            canvas.drawText(value, cx, cy + dp(2), tx);
            canvas.drawText(unit, cx, cy + dp(12), un);
        }
    }
}
