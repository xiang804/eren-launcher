package com.eren.launcherx;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** 接收 shell 脚本的指令，转成 Activity 动作。 */
public class CmdReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String cmd = intent.getStringExtra("cmd");
        if (cmd == null) {
            cmd = "assistant";
        }
        try {
            Intent i = new Intent(context, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            i.putExtra("cmd", cmd);
            context.startActivity(i);
        } catch (Exception ignored) {
        }
    }
}
