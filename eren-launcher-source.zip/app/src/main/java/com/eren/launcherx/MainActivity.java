package com.eren.launcherx;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ImageFormat;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends Activity {

    private static final int SPLASH_MS = 1600;
    static final String APP_VERSION = "1.0.22";
    /** 云更新地址：返回 JSON {"versionName":"1.0.6","url":"https://...apk"}；留空则提示未配置 */
    static final String UPDATE_URL = "https://raw.githubusercontent.com/xiang804/eren-launcher/main/update.json";
    static final String UPDATE_CFG = "/sdcard/Download/DSH-Go/update_url.txt";
    private static final int REQ_OVERLAY = 2001;
    private static final int REQ_PROJECTION = 2002;

    private static final int[] NEON = {
            0xFF29E7FF, 0xFFFF3FA7, 0xFFB388FF, 0xFF69F0AE,
            0xFFFFD740, 0xFFFF7043, 0xFF40C4FF, 0xFFE040FB
    };

    private static final String[] GAME_WORDS = {
            "游戏", "game", "王者", "和平", "精英", "原神", "崩坏", "星穹", "火影", "我的世界",
            "迷你世界", "飞车", "穿越火线", "第五人格", "光遇", "明日方舟", "蛋仔", "部落冲突",
            "皇室战争", "荒野", "金铲铲", "斗地主", "麻将", "棋", "赛车", "模拟器", "传奇", "吃鸡",
            "绝地", "使命召唤", "暗区", "地铁跑酷", "贪吃蛇", "幻想", "大话", "梦幻", "天龙",
            "逆水寒", "三国", "帝国", "红警", "植物大战僵尸", "保卫萝卜", "消消乐", "元气骑士",
            "阴阳师", "率土", "哈利", "球球", "欢乐", "英雄", "枪战", "战场", "竞技", "对决",
            "绝区零", "鸣潮", "三角洲", "永劫", "地下城", "命运", "战双", "幻塔", "碧蓝", "少女"
    };

    private static final String[] NOT_GAME = {
            "游戏盒", "游戏厅", "盒子", "助手", "加速", "安全", "美化", "工具",
            "修改", "外挂", "框架", "市场", "商店", "商城", "中心", "管家",
            "卫士", "安装", "启动器", "gg"
    };

    private final Handler ui = new Handler(Looper.getMainLooper());
    private android.speech.tts.TextToSpeech tts;
    private boolean ttsReady = false;
    private FrameLayout root;
    private GridView grid;
    private GameAdapter adapter;
    private TextView startBtn;
    private TextView floatBtn;
    private TextView hintView;
    private TextView heroTitle;
    private TextView heroSub;
    private LinearLayout gameRail;
    private ImageView heroBg;
    private View heroScrim;
    private TextView versionBtn;
    private TextView updBtn;
    private final List<GameItem> games = new ArrayList<GameItem>();
    private int selected = -1;
    private boolean overlayShowing = false;

    private AssistantUI assistant;

    private MediaProjection projection;
    private int projectionMode = 0;   // 1=截屏 2=录屏
    private MediaRecorder recorder;
    private ParcelFileDescriptor recPfd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF05060A);
        root.addView(new GlowBackdrop(this), new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        initTts();
        String cmdFromShell = getIntent() == null ? null : getIntent().getStringExtra("cmd");
        if (cmdFromShell != null) {
            ui.postDelayed(new Runnable() {
                public void run() {
                    toggleAssistant();
                }
            }, 900);
            return;
        }
        showPromo1();
    }

    /* ---------------- 公益宣传 ---------------- */

    private void initTts() {
        try {
            tts = new android.speech.tts.TextToSpeech(getApplicationContext(),
                    new android.speech.tts.TextToSpeech.OnInitListener() {
                        public void onInit(int status) {
                            if (status != android.speech.tts.TextToSpeech.SUCCESS) {
                                return;
                            }
                            try {
                                tts.setSpeechRate(0.95f);
                                tts.setPitch(1.0f);
                                int r = tts.isLanguageAvailable(java.util.Locale.CHINA);
                                if (r == android.speech.tts.TextToSpeech.LANG_MISSING_DATA
                                        || r == android.speech.tts.TextToSpeech.LANG_NOT_SUPPORTED) {
                                    r = tts.isLanguageAvailable(java.util.Locale.CHINESE);
                                    if (r >= 0) {
                                        tts.setLanguage(java.util.Locale.CHINESE);
                                    } else {
                                        tts.setLanguage(java.util.Locale.getDefault());
                                    }
                                } else {
                                    tts.setLanguage(java.util.Locale.CHINA);
                                }
                                ttsReady = true;
                            } catch (Exception ignored) {
                            }
                        }
                    });
        } catch (Exception ignored) {
        }
    }

    private void speak(final String text) {
        try {
            if (tts == null) {
                return;
            }
            final android.media.AudioManager am =
                    (android.media.AudioManager) getSystemService(Context.AUDIO_SERVICE);
            final int oldVol = am == null ? -1 : am.getStreamVolume(android.media.AudioManager.STREAM_ALARM);
            final int maxVol = am == null ? -1 : am.getStreamMaxVolume(android.media.AudioManager.STREAM_ALARM);
            if (am != null && oldVol == 0 && maxVol > 0) {
                try {
                    am.setStreamVolume(android.media.AudioManager.STREAM_ALARM,
                            Math.max(3, (int) (maxVol * 0.7f)), 0);
                } catch (Exception ignored) {
                }
            }
            if (!ttsReady) {
                // 引擎可能还在初始化，等一下就再来一次
                ui.postDelayed(new Runnable() {
                    public void run() {
                        speak(text);
                    }
                }, 600);
                return;
            }
            android.os.Bundle params = new android.os.Bundle();
            params.putInt(android.speech.tts.TextToSpeech.Engine.KEY_PARAM_STREAM,
                    android.media.AudioManager.STREAM_ALARM);
            params.putFloat(android.speech.tts.TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f);
            tts.setOnUtteranceProgressListener(new android.speech.tts.UtteranceProgressListener() {
                public void onStart(String id) {
                }

                public void onDone(String id) {
                    restoreVol(am, oldVol);
                }

                public void onError(String id) {
                    restoreVol(am, oldVol);
                }
            });
            tts.speak(text, android.speech.tts.TextToSpeech.QUEUE_FLUSH, params, "eren_welcome");
            ui.postDelayed(new Runnable() {
                public void run() {
                    restoreVol(am, oldVol);
                }
            }, 4500);
        } catch (Exception ignored) {
        }
    }

    private void restoreVol(android.media.AudioManager am, int oldVol) {
        try {
            if (am != null && oldVol >= 0) {
                am.setStreamVolume(android.media.AudioManager.STREAM_ALARM, oldVol, 0);
            }
        } catch (Exception ignored) {
        }
    }

    private void showPromo1() {
        showPromo("让善意发生", "守护你我", "别让血汗钱，\n流进骗子的口袋",
                new String[]{"他叫你“家人”，却盯着你的钱包。", "你多想一秒，骗子就少一次机会。"},
                "不轻信 · 不透露 · 不转账", 0xFF2F6BFF, 0,
                new Runnable() {
                    public void run() {
                        showPromo2();
                    }
                });
    }

    private void showPromo2() {
        showPromo("宝贝回家", "公益寻人", "每一个走失的孩子\n都在等一次回头",
                new String[]{"如果你看到独自徘徊的孩子，请多问一句。", "一次留意，可能就是一次团圆。"},
                "不围观 · 保护隐私 · 及时报警", 0xFFE8552F, 1,
                new Runnable() {
                    public void run() {
                        startSplash();
                    }
                });
    }

    private void startSplash() {
        showSplash();
        speak("欢迎使用恶認游戏助手");
        ui.postDelayed(new Runnable() {
            public void run() {
                showHome();
            }
        }, SPLASH_MS);
    }

    private void showPromo(final String kicker, final String head, final String big,
                           final String[] lines, final String tag, final int accent,
                           final int artMode, final Runnable next) {
        final FrameLayout layer = new FrameLayout(this);
        layer.setBackgroundColor(0xFF0B0F16);

        ImageView poster = new ImageView(this);
        poster.setScaleType(ImageView.ScaleType.FIT_CENTER);
        poster.setImageResource(artMode == 0 ? R.drawable.promo_fraud : R.drawable.promo_home);
        layer.addView(poster, new FrameLayout.LayoutParams(-1, -1));

        // 顶部渐变压条，保证文字可读
        View scrim = new View(this);
        GradientDrawable sg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xCC000000, 0x66000000, 0x00000000});
        scrim.setBackgroundDrawable(sg);
        layer.addView(scrim, new FrameLayout.LayoutParams(-1, dp(96), Gravity.TOP));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(16), dp(20), dp(16), dp(10));

        TextView badge = new TextView(this);
        badge.setText(artMode == 0 ? "善" : "寻");
        badge.setTextColor(0xFFFFFFFF);
        badge.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        badge.setGravity(Gravity.CENTER);
        GradientDrawable bd = new GradientDrawable();
        bd.setCornerRadius(dp(10));
        bd.setColor(accent);
        badge.setBackgroundDrawable(bd);
        top.addView(badge, new LinearLayout.LayoutParams(dp(34), dp(34)));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        TextView t1 = new TextView(this);
        t1.setText(kicker);
        t1.setTextColor(0xFFFFFFFF);
        t1.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        titles.addView(t1);
        TextView t2 = new TextView(this);
        t2.setText(head);
        t2.setTextColor(0xCCFFFFFF);
        t2.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        titles.addView(t2);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, -2, 1f);
        tlp.leftMargin = dp(10);
        top.addView(titles, tlp);

        final TextView skip = new TextView(this);
        skip.setText("跳过 (3)");
        skip.setTextColor(0xFF1B1F2A);
        skip.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        skip.setGravity(Gravity.CENTER);
        skip.setPadding(dp(14), dp(8), dp(14), dp(8));
        GradientDrawable sgbg = new GradientDrawable();
        sgbg.setCornerRadius(dp(18));
        sgbg.setColor(0xF2FFFFFF);
        skip.setBackgroundDrawable(sgbg);
        top.addView(skip, new LinearLayout.LayoutParams(-2, -2));

        layer.addView(top, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));
        root.addView(layer, new FrameLayout.LayoutParams(-1, -1));

        final boolean[] done = {false};
        final Runnable go = new Runnable() {
            public void run() {
                if (done[0]) {
                    return;
                }
                done[0] = true;
                root.removeView(layer);
                next.run();
            }
        };
        skip.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (done[0]) {
                    return;
                }
                done[0] = true;
                root.removeView(layer);
                startSplash();
            }
        });
        for (int i = 0; i <= 3; i++) {
            final int left = 3 - i;
            ui.postDelayed(new Runnable() {
                public void run() {
                    if (done[0]) {
                        return;
                    }
                    skip.setText(left > 0 ? ("跳过 (" + left + ")") : "跳过");
                    if (left == 0) {
                        go.run();
                    }
                }
            }, i * 1000L);
        }
    }

    /** 宣传插画：渐变底 + 盾牌 / 爱心 */
    static class PromoArt extends View {
        private final int accent;
        private final int mode;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        PromoArt(Context c, int accent, int mode) {
            super(c);
            this.accent = accent;
            this.mode = mode;
            setLayerType(LAYER_TYPE_SOFTWARE, null);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float w = getWidth();
            float h = getHeight();
            float r = Math.min(dp(18), Math.min(w, h) / 6f);
            p.setShader(new android.graphics.LinearGradient(0, 0, w, h,
                    new int[]{accent, darken(accent)}, null, Shader.TileMode.CLAMP));
            canvas.drawRoundRect(new RectF(0, 0, w, h), r, r, p);
            p.setShader(null);

            p.setColor(0x33FFFFFF);
            canvas.drawCircle(w * 0.78f, h * 0.28f, h * 0.32f, p);
            canvas.drawCircle(w * 0.18f, h * 0.82f, h * 0.24f, p);

            // 人物剪影：两位大人 + 中间一个小孩
            p.setColor(0xE6FFFFFF);
            float by = h * 0.52f;
            float bh = h * 0.34f;
            drawPerson(canvas, w * 0.34f, by, bh, 1.0f);
            drawPerson(canvas, w * 0.66f, by, bh, 1.0f);
            p.setColor(0xFFFFFFFF);
            drawPerson(canvas, w * 0.5f, by + bh * 0.18f, bh * 0.68f, 1.0f);

            p.setColor(0xEEFFFFFF);
            float cx = w / 2f;
            float cy = h / 2f;
            float s = Math.min(w, h) * 0.22f;
            if (mode == 0) {
                android.graphics.Path shield = new android.graphics.Path();
                shield.moveTo(cx, cy - s);
                shield.lineTo(cx + s * 0.85f, cy - s * 0.5f);
                shield.lineTo(cx + s * 0.72f, cy + s * 0.45f);
                shield.quadTo(cx, cy + s * 1.15f, cx - s * 0.72f, cy + s * 0.45f);
                shield.lineTo(cx - s * 0.85f, cy - s * 0.5f);
                shield.close();
                canvas.drawPath(shield, p);
                p.setColor(accent);
                android.graphics.Path tick = new android.graphics.Path();
                tick.moveTo(cx - s * 0.35f, cy);
                tick.lineTo(cx - s * 0.08f, cy + s * 0.3f);
                tick.lineTo(cx + s * 0.4f, cy - s * 0.28f);
                tick.lineTo(cx - s * 0.05f, cy + s * 0.18f);
                tick.close();
                canvas.drawPath(tick, p);
            } else {
                android.graphics.Path heart = new android.graphics.Path();
                heart.moveTo(cx, cy + s * 0.85f);
                heart.cubicTo(cx - s * 1.5f, cy - s * 0.15f, cx - s * 0.6f, cy - s * 1.05f, cx, cy - s * 0.35f);
                heart.cubicTo(cx + s * 0.6f, cy - s * 1.05f, cx + s * 1.5f, cy - s * 0.15f, cx, cy + s * 0.85f);
                heart.close();
                canvas.drawPath(heart, p);
            }
        }

        private void drawPerson(Canvas canvas, float x, float y, float bodyH, float scale) {
            float headR = bodyH * 0.22f * scale;
            canvas.drawCircle(x, y - bodyH * 0.82f, headR, p);
            RectF body = new RectF(x - bodyH * 0.26f * scale, y - bodyH * 0.58f,
                    x + bodyH * 0.26f * scale, y + bodyH * 0.12f);
            canvas.drawRoundRect(body, bodyH * 0.2f, bodyH * 0.2f, p);
        }

        private int darken(int c) {
            int r = (int) (((c >> 16) & 0xFF) * 0.65f);
            int g = (int) (((c >> 8) & 0xFF) * 0.65f);
            int b = (int) ((c & 0xFF) * 0.65f);
            return 0xFF000000 | (r << 16) | (g << 8) | b;
        }

        private float dp(float v) {
            return v * getResources().getDisplayMetrics().density;
        }
    }

    /* ---------------- 开场 ---------------- */

    private void showSplash() {
        final FrameLayout layer = new FrameLayout(this);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER);

        NeonText title = new NeonText(this);
        title.setText("欢迎使用恶認游戏启动器");
        title.setColors(NEON);
        title.setTextSizePx(getResources().getDisplayMetrics().widthPixels / 14.5f);
        title.setLetterGap(1.02f);
        col.addView(title, new LinearLayout.LayoutParams(-1, -2));

        View gap = new View(this);
        col.addView(gap, new LinearLayout.LayoutParams(1, dp(26)));

        LoadingBar bar = new LoadingBar(this);
        LinearLayout.LayoutParams barLp = new LinearLayout.LayoutParams(dp(190), dp(5));
        barLp.gravity = Gravity.CENTER_HORIZONTAL;
        col.addView(bar, barLp);

        layer.addView(col, new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER));
        root.addView(layer, new FrameLayout.LayoutParams(-1, -1));

        title.startReveal(1000);
        bar.start(SPLASH_MS - 150);
    }

    /* ---------------- 主界面 ---------------- */

    private void showHome() {
        for (int i = root.getChildCount() - 1; i >= 0; i--) {
            if (root.getChildAt(i) instanceof GlowBackdrop) {
                continue;
            }
            root.removeViewAt(i);
        }

        FrameLayout page = new FrameLayout(this);
        page.setBackgroundColor(0xF2050810);

        heroBg = new ImageView(this);
        heroBg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        heroBg.setAlpha(0.55f);
        page.addView(heroBg, new FrameLayout.LayoutParams(-1, -1));

        heroScrim = new View(this);
        GradientDrawable scrim = new GradientDrawable(
                GradientDrawable.Orientation.BOTTOM_TOP,
                new int[]{0xF2050810, 0x66050810, 0x00050810});
        heroScrim.setBackgroundDrawable(scrim);
        page.addView(heroScrim, new FrameLayout.LayoutParams(-1, -1));

        // ---- 顶部：游戏图标横排 + 搜索 + 头像 ----
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(12), dp(14), dp(12), 0);

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        gameRail = new LinearLayout(this);
        gameRail.setOrientation(LinearLayout.HORIZONTAL);
        hs.addView(gameRail);
        header.addView(hs, new LinearLayout.LayoutParams(0, dp(56), 1f));

        TextView search = new TextView(this);
        search.setText("  ⌕  搜索游戏");
        search.setTextColor(0x99FFFFFF);
        search.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        search.setGravity(Gravity.CENTER_VERTICAL);
        GradientDrawable sg = new GradientDrawable();
        sg.setCornerRadius(dp(20));
        sg.setColor(0x1AFFFFFF);
        search.setBackgroundDrawable(sg);
        search.setPadding(dp(10), 0, dp(10), 0);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(0, dp(36), 1.1f);
        sp.leftMargin = dp(8);
        header.addView(search, sp);

        TextView upd = new TextView(this);
        updBtn = upd;
        upd.setText("更新");
        upd.setTextColor(0xFFE8FBFF);
        upd.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        upd.setGravity(Gravity.CENTER);
        GradientDrawable ug = new GradientDrawable();
        ug.setCornerRadius(dp(14));
        ug.setColor(0x33FF8A3D);
        upd.setBackgroundDrawable(ug);
        upd.setPadding(dp(8), dp(4), dp(8), dp(4));
        upd.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (versionBtn != null) {
                    versionBtn.performClick();
                } else {
                    checkUpdate();
                }
            }
        });
        LinearLayout.LayoutParams ulp = new LinearLayout.LayoutParams(-2, -2);
        ulp.leftMargin = dp(6);
        header.addView(upd, ulp);

        TextView avatar = new TextView(this);
        avatar.setText("我");
        avatar.setTextColor(0xFF05080F);
        avatar.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        avatar.setGravity(Gravity.CENTER);
        GradientDrawable ag = new GradientDrawable();
        ag.setShape(GradientDrawable.OVAL);
        ag.setColor(0xFFE8FBFF);
        avatar.setBackgroundDrawable(ag);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(dp(36), dp(36));
        ap.leftMargin = dp(8);
        header.addView(avatar, ap);

        page.addView(header, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));

        // ---- 中部英雄标题 ----
        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(18), 0, dp(18), dp(96));

        heroTitle = new TextView(this);
        heroTitle.setText("选一个游戏");
        heroTitle.setTextColor(0xFFFFFFFF);
        int sw = getResources().getConfiguration().screenWidthDp;
        heroTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, sw >= 600 ? (sw >= 900 ? 40 : 32) : 26);
        heroTitle.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
        hero.addView(heroTitle);

        heroSub = new TextView(this);
        heroSub.setText("正在扫描…");
        heroSub.setTextColor(0x99FFFFFF);
        heroSub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        LinearLayout.LayoutParams hsl = new LinearLayout.LayoutParams(-1, -2);
        hsl.topMargin = dp(4);
        hero.addView(heroSub, hsl);

        page.addView(hero, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));

        // ---- 启动按钮（右下） ----
        startBtn = new TextView(this);
        startBtn.setText("启动游戏  ›");
        startBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        startBtn.setGravity(Gravity.CENTER);
        startBtn.setPadding(dp(26), dp(12), dp(26), dp(12));
        FrameLayout.LayoutParams sbp = new FrameLayout.LayoutParams(-2, -2,
                Gravity.BOTTOM | Gravity.RIGHT);
        sbp.rightMargin = dp(18);
        sbp.bottomMargin = dp(100);
        page.addView(startBtn, sbp);
        startBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startSelected();
            }
        });

        // ---- 底部四张卡片 ----
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setPadding(dp(10), 0, dp(10), dp(12));
        bar.addView(barCard("游戏设置", "性能调节", new Runnable() {
            public void run() {
                toggleAssistant();
            }
        }), new LinearLayout.LayoutParams(0, dp(58), 1f));
        bar.addView(barCard("游戏加速", "启动快人一步", new Runnable() {
            public void run() {
                toastLong("在悬浮助手「性能」页开启电竞模式");
            }
        }), new LinearLayout.LayoutParams(0, dp(58), 1f));
        bar.addView(barCard("游戏相册", "截图与录屏", new Runnable() {
            public void run() {
                toastLong("截图保存在 相册/Pictures/恶認助手");
            }
        }), new LinearLayout.LayoutParams(0, dp(58), 1.2f));
        bar.addView(barCard("悬浮助手", "挂边工具栏", new Runnable() {
            public void run() {
                toggleAssistant();
            }
        }), new LinearLayout.LayoutParams(0, dp(58), 1.3f));
        page.addView(bar, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));

        root.addView(page, new FrameLayout.LayoutParams(-1, -1));

        new Thread(new Runnable() {
            public void run() {
                final List<GameItem> found = scanGames();
                ui.post(new Runnable() {
                    public void run() {
                        games.clear();
                        games.addAll(found);
                        selected = games.isEmpty() ? -1 : 0;
                        rebuildRail();
                        updateHero();
                    }
                });
            }
        }).start();
    }

    private View barCard(String title, String sub, final Runnable action) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(10), dp(8), dp(10), dp(8));
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(16));
        g.setColor(0x14FFFFFF);
        card.setBackgroundDrawable(g);

        TextView t = new TextView(this);
        t.setText(title);
        t.setTextColor(0xFFE8FBFF);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        card.addView(t);

        TextView s = new TextView(this);
        s.setText(sub);
        s.setTextColor(0x77FFFFFF);
        s.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9);
        card.addView(s);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(58), 1f);
        lp.rightMargin = dp(6);
        card.setLayoutParams(lp);
        card.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                action.run();
            }
        });
        return card;
    }

    private void rebuildRail() {
        if (gameRail == null) {
            return;
        }
        gameRail.removeAllViews();
        for (int i = 0; i < games.size() && i < 12; i++) {
            final int idx = i;
            FrameLayout cell = new FrameLayout(this);
            ImageView iv = new ImageView(this);
            if (games.get(i).icon != null) {
                iv.setImageDrawable(games.get(i).icon);
            }
            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(dp(12));
            bg.setColor(0x22FFFFFF);
            FrameLayout inner = new FrameLayout(this);
            inner.setBackgroundDrawable(bg);
            inner.setPadding(dp(4), dp(4), dp(4), dp(4));
            inner.addView(iv, new FrameLayout.LayoutParams(-1, -1));
            int iconSide = getResources().getConfiguration().screenWidthDp >= 600 ? dp(60) : dp(48);
            cell.addView(inner, new FrameLayout.LayoutParams(iconSide, iconSide, Gravity.CENTER));

            GradientDrawable ring = new GradientDrawable();
            ring.setCornerRadius(dp(14));
            ring.setColor(0x00000000);
            if (i == selected) {
                ring.setStroke(dp(2), 0xFFFFFFFF);
            }
            cell.setBackgroundDrawable(ring);
            cell.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    selected = idx;
                    rebuildRail();
                    updateHero();
                    updateButtons();
                }
            });
            int cellSide = getResources().getConfiguration().screenWidthDp >= 600 ? dp(72) : dp(56);
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(cellSide, cellSide);
            clp.rightMargin = dp(6);
            gameRail.addView(cell, clp);
        }
    }

    private void updateHero() {
        if (heroBg != null) {
            try {
                if (selected >= 0 && selected < games.size() && games.get(selected).icon != null) {
                    int n = 160;
                    Bitmap bmp = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888);
                    android.graphics.Canvas c = new android.graphics.Canvas(bmp);
                    Drawable d = games.get(selected).icon;
                    d.setBounds(0, 0, n, n);
                    d.draw(c);
                    Bitmap big = Bitmap.createScaledBitmap(bmp, 640, 640, true);
                    heroBg.setImageBitmap(big);
                } else {
                    heroBg.setImageBitmap(null);
                }
            } catch (Exception ignored) {
            }
        }
        if (selected >= 0 && selected < games.size()) {
            heroTitle.setText(games.get(selected).label);
            heroSub.setText("已识别 " + games.size() + " 个游戏 · 左右滑动切换");
        } else {
            heroTitle.setText("没识别到游戏");
            heroSub.setText("确认游戏已安装后重进");
        }
        updateButtons();
    }

    void updateButtons() {
        if (startBtn == null) {
            return;
        }
        boolean has = selected >= 0 && selected < games.size();
        GradientDrawable g1 = new GradientDrawable();
        g1.setCornerRadius(dp(24));
        if (has) {
            g1.setColors(new int[]{0xFF29E7FF, 0xFF7C4DFF});
            g1.setOrientation(GradientDrawable.Orientation.LEFT_RIGHT);
        } else {
            g1.setColor(0x22FFFFFF);
        }
        startBtn.setBackgroundDrawable(g1);
        startBtn.setTextColor(has ? 0xFF04121A : 0x66FFFFFF);
        if (has) {
            startBtn.setShadowLayer(14f, 0f, 0f, 0xFF29E7FF);
        } else {
            startBtn.setShadowLayer(0f, 0f, 0f, 0);
        }

        if (floatBtn == null) {
            return;
        }
        boolean on = assistant != null && assistant.isShowing();
        GradientDrawable g2 = new GradientDrawable();
        g2.setCornerRadius(dp(14));
        g2.setColor(on ? 0x33FF3FA7 : 0x14FFFFFF);
        g2.setStroke(on ? dp(1) + 1 : 1, on ? 0xFFFF3FA7 : 0x33FFFFFF);
        floatBtn.setBackgroundDrawable(g2);
        floatBtn.setTextColor(on ? 0xFFFFE7F4 : 0x66FFFFFF);
        if (on) {
            floatBtn.setShadowLayer(14f, 0f, 0f, 0xFFFF3FA7);
        } else {
            floatBtn.setShadowLayer(0f, 0f, 0f, 0);
        }
    }

    /* ---------------- 脚本执行面板 ---------------- */

    void runShellScript(final String arg) {
        new Thread(new Runnable() {
            public void run() {
                String cmd = "sh /sdcard/eren.sh " + arg;
                String out = RootUtil.run(cmd);
                if (out == null || out.length() == 0) {
                    out = "(无输出；如果一直为空，可能是 su 未授权或脚本路径不可读)";
                }
                final String text = "$ su -c " + cmd + "\n\n" + out;
                ui.post(new Runnable() {
                    public void run() {
                        try {
                            new android.app.AlertDialog.Builder(MainActivity.this)
                                    .setTitle("shell 输出")
                                    .setMessage(text)
                                    .setPositiveButton("知道了", null)
                                    .show();
                        } catch (Exception ignored) {
                        }
                    }
                });
            }
        }).start();
    }

    /* ---------------- 云更新 ---------------- */

    private String resolveUpdateUrl() {
        String url = "";
        try {
            java.io.File f = new java.io.File(getExternalFilesDir(null), "update_url.txt");
            if (!f.exists()) {
                f = new java.io.File(android.os.Environment.getExternalStorageDirectory(),
                        "Download/update_url.txt");
            }
            if (!f.exists()) {
                f = new java.io.File(UPDATE_CFG);
            }
            if (f.exists()) {
                java.io.BufferedReader br = new java.io.BufferedReader(
                        new java.io.InputStreamReader(new java.io.FileInputStream(f), "UTF-8"));
                String line = br.readLine();
                br.close();
                if (line != null) {
                    url = line.trim();
                }
            }
        } catch (Exception ignored) {
        }
        if (url.length() == 0) {
            url = UPDATE_URL;
        }
        if (url.startsWith("gh:")) {
            String repo = url.substring(3).trim();
            return "https://api.github.com/repos/" + repo + "/releases/latest";
        }
        return url;
    }

    /** 以清单里的 versionName 为准，避免代码常量滞后。 */
    private String realVersionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) {
            return APP_VERSION;
        }
    }

    private boolean isNewer(String remote, String local) {
        try {
            String[] a = remote.trim().split("\\.");
            String[] b = local.trim().split("\\.");
            int n = Math.max(a.length, b.length);
            for (int i = 0; i < n; i++) {
                int x = i < a.length ? Integer.parseInt(a[i].replaceAll("[^0-9]", "")) : 0;
                int y = i < b.length ? Integer.parseInt(b[i].replaceAll("[^0-9]", "")) : 0;
                if (x > y) {
                    return true;
                }
                if (x < y) {
                    return false;
                }
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    private boolean hasAllFiles() {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                return android.os.Environment.isExternalStorageManager();
            }
            return true;
        } catch (Exception e) {
            return true;
        }
    }

    private void askAllFiles() {
        toastLong("云更新需要「所有文件访问」权限，请在设置里打开");
        try {
            startActivity(new Intent(android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
        } catch (Exception e) {
            toastLong("打不开权限页，请手动到 设置→应用→所有文件访问 打开");
        }
    }

    private TextView updTarget() {
        return versionBtn != null ? versionBtn : updBtn;
    }

    private void checkUpdate() {
        final String current = realVersionName();
        if (!hasAllFiles()) {
            askAllFiles();
            return;
        }
        String[] localFirst = readLocalUpdate(current);
        String localVer = readLocalVersion();
        if (localFirst == null && localVer != null && localVer.length() > 0) {
            toastLong("已是最新版本 v" + current);
            return;
        }
        if (localFirst != null) {
            TextView tgt = updTarget();
            if (tgt == null) {
                toastLong("发现新版本 " + localFirst[0]);
                return;
            }
            tgt.setText("新版本 " + localFirst[0]);
            tgt.setTextColor(0xFFFFC49A);
            final String apkPath = localFirst[1];
            tgt.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    installApk(apkPath);
                }
            });
            toastLong("发现新版本 " + localFirst[0] + "（当前 " + current + "）");
            return;
        }
        String target = resolveUpdateUrl();
        if (target == null || target.length() == 0) {
            toastLong("已是最新版本 v" + APP_VERSION + "（更新服务还没配置地址）");
            return;
        }
        toastLong("正在检查更新…");
        new Thread(new Runnable() {
            public void run() {
                try {
                    java.net.HttpURLConnection c = (java.net.HttpURLConnection)
                            new java.net.URL(target).openConnection();
                    c.setRequestProperty("User-Agent", "ErenLauncher");
                    c.setConnectTimeout(8000);
                    c.setReadTimeout(8000);
                    java.io.BufferedReader br = new java.io.BufferedReader(
                            new java.io.InputStreamReader(c.getInputStream(), "UTF-8"));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) {
                        sb.append(line);
                    }
                    br.close();
                    org.json.JSONObject o = new org.json.JSONObject(sb.toString());
                    String ver = o.optString("versionName", "");
                    String url = o.optString("url", "");
                    if (ver.length() == 0) {
                        ver = o.optString("tag_name", "");
                        if (ver.startsWith("v") || ver.startsWith("V")) {
                            ver = ver.substring(1);
                        }
                    }
                    if (url.length() == 0) {
                        org.json.JSONArray arr = o.optJSONArray("assets");
                        if (arr != null && arr.length() > 0) {
                            url = arr.getJSONObject(0).optString("browser_download_url", "");
                        }
                    }
                    final String verF = ver;
                    final String urlF = url;
                    ui.post(new Runnable() {
                        public void run() {
                            if (verF.length() == 0 || !isNewer(verF, current)) {
                                toastLong("已是最新版本 v" + current);
                            } else if (versionBtn != null) {
                                TextView tv2 = updTarget();
                                if (tv2 == null) {
                                    return;
                                }
                                tv2.setText("新版本 " + verF);
                                tv2.setTextColor(0xFFFFC49A);
                                setVersionClickToDownload(urlF);
                            }
                        }
                    });
                } catch (final Exception e) {
                    final String[] local = readLocalUpdate(current);
                    ui.post(new Runnable() {
                        public void run() {
                            if (local != null) {
                                versionBtn.setText("发现新版本 v" + local[0] + "（本地包）点我更新");
                                versionBtn.setTextColor(0xFFFFC49A);
                                final String apk = local[1];
                                versionBtn.setOnClickListener(new View.OnClickListener() {
                                    public void onClick(View v) {
                                        if (RootUtil.available()) {
                                            RootUtil.run("pm install -r -d " + apk);
                                            toastLong("已用 root 安装本地新包");
                                        } else {
                                            toastLong("本地包：" + apk);
                                        }
                                    }
                                });
                            } else {
                                toastLong("检查更新失败：" + e.getClass().getSimpleName());
                            }
                        }
                    });
                }
            }
        }).start();
    }

    /** 返回 {版本, apk路径}；读不到返回 null。 */
    private String readLocalVersion() {
        try {
            java.io.File dir = new java.io.File(android.os.Environment.getExternalStorageDirectory(),
                    "Download/DSH-Go");
            java.io.File json = new java.io.File(dir, "update.json");
            if (!json.exists()) {
                return null;
            }
            java.io.BufferedReader br = new java.io.BufferedReader(
                    new java.io.InputStreamReader(new java.io.FileInputStream(json), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            br.close();
            return new org.json.JSONObject(sb.toString()).optString("versionName", "");
        } catch (Exception e) {
            return null;
        }
    }

    private String[] readLocalUpdate(String current) {
        try {
            java.io.File dir = new java.io.File(android.os.Environment.getExternalStorageDirectory(),
                    "Download/DSH-Go");
            java.io.File json = new java.io.File(dir, "update.json");
            if (!json.exists()) {
                return null;
            }
            java.io.BufferedReader br = new java.io.BufferedReader(
                    new java.io.InputStreamReader(new java.io.FileInputStream(json), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            br.close();
            org.json.JSONObject o = new org.json.JSONObject(sb.toString());
            String ver = o.optString("versionName", "");
            String apk = o.optString("localApk", "");
            if (apk.length() == 0) {
                apk = new java.io.File(dir, "ErenLauncher.apk").getAbsolutePath();
            }
            if (ver.length() == 0 || !isNewer(ver, current)) {
                return null;
            }
            return new String[]{ver, apk};
        } catch (Exception e) {
            return null;
        }
    }

    private void setVersionClickToDownload(final String url) {
        if (versionBtn == null) {
            return;
        }
        versionBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                downloadUpdate(url);
            }
        });
    }

    private void downloadUpdate(final String url) {
        toastLong("开始下载新版本…");
        new Thread(new Runnable() {
            public void run() {
                try {
                    java.io.File dir = getExternalFilesDir(null);
                    if (dir == null) {
                        dir = getFilesDir();
                    }
                    final java.io.File out = new java.io.File(dir, "ErenLauncher_" + System.currentTimeMillis() + ".apk");
                    java.net.HttpURLConnection c = (java.net.HttpURLConnection)
                            new java.net.URL(url).openConnection();
                    c.setConnectTimeout(10000);
                    java.io.InputStream in = c.getInputStream();
                    java.io.FileOutputStream fo = new java.io.FileOutputStream(out);
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        fo.write(buf, 0, n);
                    }
                    fo.close();
                    in.close();
                    final String apkPath = out.getAbsolutePath();
                    installApk(apkPath);
                    ui.post(new Runnable() {
                        public void run() {
                            toastLong("新版本已下载，正在打开安装器");
                            if (versionBtn != null) {
                                versionBtn.setText("v" + APP_VERSION);
                            }
                        }
                    });
                } catch (final Exception e) {
                    ui.post(new Runnable() {
                        public void run() {
                            toastLong("下载失败：" + e.getClass().getSimpleName());
                        }
                    });
                }
            }
        }).start();
    }

    /** 有 root 静默安装；没有 root 交给系统安装器（免 root）。 */
    void installApk(final String path) {
        new Thread(new Runnable() {
            public void run() {
                boolean rooted = RootUtil.available();
                if (rooted) {
                    RootUtil.run("pm install -r -d " + path);
                    ui.post(new Runnable() {
                        public void run() {
                            toastLong("已用 root 安装，重启应用生效");
                        }
                    });
                    return;
                }
                final String p = path;
                ui.post(new Runnable() {
                    public void run() {
                        try {
                            java.io.File f = new java.io.File(p);
                            android.net.Uri uri = android.net.Uri.parse(
                                    "content://" + ApkProvider.AUTHORITY + f.getAbsolutePath());
                            Intent i = new Intent(Intent.ACTION_VIEW);
                            i.setDataAndType(uri, "application/vnd.android.package-archive");
                            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(i);
                        } catch (Exception e) {
                            toastLong("打开安装器失败：" + e.getClass().getSimpleName() + "，文件在 " + p);
                        }
                    }
                });
            }
        }).start();
    }

    private void toastLong(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    /* ---------------- 悬浮助手 ---------------- */

    private void toggleAssistant() {
        if (assistant != null && assistant.isShowing()) {
            assistant.hide();
            assistant = null;
            updateButtons();
            return;
        }
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "先授予悬浮窗权限", Toast.LENGTH_SHORT).show();
            try {
                startActivityForResult(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())), REQ_OVERLAY);
            } catch (Exception e) {
                Toast.makeText(this, "打不开权限页，请手动到设置里授权", Toast.LENGTH_LONG).show();
            }
            return;
        }
        assistant = new AssistantUI(this);
        assistant.show();
        updateButtons();
        Toast.makeText(this, "悬浮助手已开启，拖到屏幕边缘会自动贴边", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_OVERLAY) {
            if (Build.VERSION.SDK_INT >= 23 && Settings.canDrawOverlays(this)) {
                assistant = new AssistantUI(this);
                assistant.show();
                updateButtons();
            } else {
                Toast.makeText(this, "没有悬浮窗权限，功能用不了", Toast.LENGTH_SHORT).show();
            }
            return;
        }
        if (requestCode == REQ_PROJECTION) {
            if (resultCode != RESULT_OK || data == null) {
                Toast.makeText(this, "取消了屏幕采集授权", Toast.LENGTH_SHORT).show();
                return;
            }
            MediaProjectionManager mgr =
                    (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            try {
                projection = mgr.getMediaProjection(resultCode, data);
            } catch (Exception e) {
                Toast.makeText(this, "获取投射失败：" + e.getClass().getSimpleName(), Toast.LENGTH_LONG).show();
                return;
            }
            if (projectionMode == 1) {
                captureOnce();
            } else if (projectionMode == 2) {
                startRecording();
            }
        }
    }

    void requestProjection(int mode) {
        projectionMode = mode;
        MediaProjectionManager mgr =
                (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        try {
            startForegroundService(new Intent(this, CaptureService.class));
        } catch (Exception ignored) {
        }
        try {
            startActivityForResult(mgr.createScreenCaptureIntent(), REQ_PROJECTION);
        } catch (Exception e) {
            Toast.makeText(this, "无法发起屏幕采集：" + e.getClass().getSimpleName(), Toast.LENGTH_LONG).show();
        }
    }

    private void captureOnce() {
        final DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getRealMetrics(dm);
        final int w = dm.widthPixels;
        final int h = dm.heightPixels;
        final ImageReader reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2);
        final VirtualDisplay[] vd = new VirtualDisplay[1];
        try {
            vd[0] = projection.createVirtualDisplay("shot", w, h, dm.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    reader.getSurface(), null, ui);
        } catch (Exception e) {
            Toast.makeText(this, "截屏失败：" + e.getClass().getSimpleName(), Toast.LENGTH_LONG).show();
            return;
        }
        ui.postDelayed(new Runnable() {
            public void run() {
                Image img = null;
                try {
                    img = reader.acquireLatestImage();
                    if (img == null) {
                        Toast.makeText(MainActivity.this, "没抓到画面，再试一次", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    Image.Plane[] planes = img.getPlanes();
                    java.nio.ByteBuffer buf = planes[0].getBuffer();
                    int pixelStride = planes[0].getPixelStride();
                    int rowStride = planes[0].getRowStride();
                    int rowPadding = rowStride - pixelStride * w;
                    Bitmap bmp = Bitmap.createBitmap(w + rowPadding / pixelStride, h, Bitmap.Config.ARGB_8888);
                    bmp.copyPixelsFromBuffer(buf);
                    Bitmap cropped = Bitmap.createBitmap(bmp, 0, 0, w, h);
                    saveShot(cropped);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "保存失败：" + e.getClass().getSimpleName(), Toast.LENGTH_LONG).show();
                } finally {
                    if (img != null) {
                        img.close();
                    }
                    reader.close();
                    if (vd[0] != null) {
                        vd[0].release();
                    }
                    if (projection != null) {
                        projection.stop();
                        projection = null;
                    }
                }
            }
        }, 600);
    }

    private void saveShot(Bitmap bmp) {
        String name = "shot_" + System.currentTimeMillis() + ".png";
        try {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Images.Media.DISPLAY_NAME, name);
            cv.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            cv.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/恶認助手");
            Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
            if (uri == null) {
                throw new Exception("insert failed");
            }
            OutputStream os = getContentResolver().openOutputStream(uri);
            bmp.compress(Bitmap.CompressFormat.PNG, 100, os);
            os.close();
            Toast.makeText(this, "截图已存到 相册/Pictures/恶認助手", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "写相册失败：" + e.getClass().getSimpleName(), Toast.LENGTH_LONG).show();
        }
    }

    private void startRecording() {
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getRealMetrics(dm);
        int w = dm.widthPixels & ~1;
        int h = dm.heightPixels & ~1;
        try {
            recorder = new MediaRecorder();
            recorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            recorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
            recorder.setVideoSize(w, h);
            recorder.setVideoFrameRate(30);
            recorder.setVideoEncodingBitRate(8000000);
            String name = "rec_" + System.currentTimeMillis() + ".mp4";
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Video.Media.DISPLAY_NAME, name);
            cv.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
            cv.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/恶認助手");
            Uri videoUri = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv);
            if (videoUri == null) {
                throw new Exception("insert video failed");
            }
            recPfd = getContentResolver().openFileDescriptor(videoUri, "w");
            recorder.setOutputFile(recPfd.getFileDescriptor());
            recorder.prepare();
            final VirtualDisplay vd = projection.createVirtualDisplay("rec", w, h, dm.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    recorder.getSurface(), null, ui);
            recorder.start();
            Toast.makeText(this, "开始录屏，结束后存到相册 Movies/恶認助手", Toast.LENGTH_SHORT).show();
            assistant.setRecording(true, new Runnable() {
                public void run() {
                    try {
                        recorder.stop();
                    } catch (Exception ignored) {
                    }
                    try {
                        recorder.reset();
                        recorder.release();
                    } catch (Exception ignored) {
                    }
                    recorder = null;
                    vd.release();
                    if (projection != null) {
                        projection.stop();
                        projection = null;
                    }
                    try {
                        if (recPfd != null) {
                            recPfd.close();
                            recPfd = null;
                        }
                    } catch (Exception ignored) {
                    }
                    Toast.makeText(MainActivity.this, "录屏已保存到相册：Movies/恶認助手", Toast.LENGTH_LONG).show();
                }
            });
        } catch (Exception e) {
            Toast.makeText(this, "录屏启动失败：" + e.getClass().getSimpleName(), Toast.LENGTH_LONG).show();
            recorder = null;
        }
    }

    /* ---------------- 启动游戏 ---------------- */

    List<GameItem> gamesSnapshot() {
        return new ArrayList<GameItem>(games);
    }

    void launchFromAssistant(GameItem item) {
        launch(item);
    }

    private void startSelected() {
        if (overlayShowing) {
            return;
        }
        if (selected < 0 || selected >= games.size()) {
            Toast.makeText(this, "先选一个游戏", Toast.LENGTH_SHORT).show();
            return;
        }
        playLaunchAnimation(games.get(selected));
    }

    private void playLaunchAnimation(final GameItem item) {
        overlayShowing = true;
        final FrameLayout overlay = new FrameLayout(this);
        overlay.setBackgroundColor(0xFF05060A);

        final WarpTunnel tunnel = new WarpTunnel(this);
        tunnel.setAlpha(0f);
        overlay.addView(tunnel, new FrameLayout.LayoutParams(-1, -1));

        final RingBadge ring = new RingBadge(this);
        FrameLayout.LayoutParams ringLp = new FrameLayout.LayoutParams(dp(230), dp(230), Gravity.CENTER);
        ringLp.topMargin = -dp(30);
        overlay.addView(ring, ringLp);
        ring.start();

        NeonText text = new NeonText(this);
        text.setText(item.label);
        text.setColors(NEON);
        float size = getResources().getDisplayMetrics().widthPixels / (item.label.length() + 4f);
        if (size > dp(28)) {
            size = dp(28);
        }
        if (size < dp(14)) {
            size = dp(14);
        }
        text.setTextSizePx(size);
        FrameLayout.LayoutParams tLp = new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER);
        tLp.topMargin = -dp(30);
        overlay.addView(text, tLp);

        TextView sub = new TextView(this);
        sub.setText("L O A D I N G");
        sub.setTextColor(0xFF8FE9FF);
        sub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        sub.setLetterSpacing(0.4f);
        sub.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams sLp = new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER);
        sLp.topMargin = dp(150);
        overlay.addView(sub, sLp);

        root.addView(overlay, new FrameLayout.LayoutParams(-1, -1));
        text.startReveal(1000);

        ui.postDelayed(new Runnable() {
            public void run() {
                tunnel.setAlpha(1f);
                tunnel.start(950);
                ring.fly();
            }
        }, 1250);

        ui.postDelayed(new Runnable() {
            public void run() {
                root.removeView(overlay);
                overlayShowing = false;
                launch(item);
            }
        }, 2200);
    }

    private void launch(GameItem item) {
        try {
            Intent i = new Intent(item.intent);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            startActivity(i);
            if (assistant == null || !assistant.isShowing()) {
                if (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)) {
                    assistant = new AssistantUI(this);
                    assistant.show();
                    updateButtons();
                }
            }
        } catch (Exception e) {
            Toast.makeText(this, "启动失败：" + e.getClass().getSimpleName(), Toast.LENGTH_SHORT).show();
        }
    }

    /* ---------------- 扫描游戏 ---------------- */

    private List<GameItem> scanGames() {
        PackageManager pm = getPackageManager();
        List<GameItem> result = new ArrayList<GameItem>();
        List<ApplicationInfo> all = pm.getInstalledApplications(0);
        for (int i = 0; i < all.size(); i++) {
            ApplicationInfo ai = all.get(i);
            if (ai == null || ai.packageName == null) {
                continue;
            }
            if (ai.packageName.equals(getPackageName())) {
                continue;
            }
            Intent launchIntent;
            try {
                launchIntent = pm.getLaunchIntentForPackage(ai.packageName);
            } catch (Exception e) {
                continue;
            }
            if (launchIntent == null) {
                continue;
            }

            String label;
            try {
                label = pm.getApplicationLabel(ai).toString();
            } catch (Exception e) {
                label = ai.packageName;
            }
            if (looksLikeNotGame(label)) {
                continue;
            }

            boolean isGame = (ai.flags & ApplicationInfo.FLAG_IS_GAME) != 0;
            if (!isGame && ai.category == 1) {
                isGame = true;
            }
            if (!isGame) {
                isGame = looksLikeGame(label);
            }
            if (!isGame) {
                continue;
            }

            Drawable icon;
            try {
                icon = ai.loadIcon(pm);
            } catch (Exception e) {
                icon = null;
            }

            GameItem gi = new GameItem();
            gi.label = label;
            gi.pkg = ai.packageName;
            gi.icon = icon;
            gi.intent = launchIntent;
            result.add(gi);
        }
        Collections.sort(result, new Comparator<GameItem>() {
            public int compare(GameItem a, GameItem b) {
                return a.label.compareToIgnoreCase(b.label);
            }
        });
        return result;
    }

    private boolean looksLikeGame(String label) {
        if (label == null) {
            return false;
        }
        String lower = label.toLowerCase();
        for (int i = 0; i < GAME_WORDS.length; i++) {
            if (lower.contains(GAME_WORDS[i].toLowerCase())) {
                return true;
            }
        }
        return false;
    }

    private boolean looksLikeNotGame(String label) {
        if (label == null) {
            return false;
        }
        String lower = label.toLowerCase();
        for (int i = 0; i < NOT_GAME.length; i++) {
            if (lower.contains(NOT_GAME[i].toLowerCase())) {
                return true;
            }
        }
        return false;
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    static class GameItem {
        String label;
        String pkg;
        Drawable icon;
        Intent intent;
    }

    class GameAdapter extends BaseAdapter {
        public int getCount() {
            return games.size();
        }

        public Object getItem(int position) {
            return games.get(position);
        }

        public long getItemId(int position) {
            return position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            LinearLayout cell;
            if (convertView == null) {
                cell = new LinearLayout(MainActivity.this);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setGravity(Gravity.CENTER);
                cell.setPadding(dp(6), dp(10), dp(6), dp(10));

                ImageView iv = new ImageView(MainActivity.this);
                iv.setTag("icon");
                cell.addView(iv, new LinearLayout.LayoutParams(dp(52), dp(52)));

                TextView tv = new TextView(MainActivity.this);
                tv.setTag("name");
                tv.setTextColor(0xFFE8FBFF);
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
                tv.setGravity(Gravity.CENTER);
                tv.setMaxLines(1);
                tv.setEllipsize(android.text.TextUtils.TruncateAt.END);
                LinearLayout.LayoutParams tvLp = new LinearLayout.LayoutParams(-1, -2);
                tvLp.topMargin = dp(6);
                cell.addView(tv, tvLp);
            } else {
                cell = (LinearLayout) convertView;
            }

            GameItem item = games.get(position);
            ImageView icon = (ImageView) cell.findViewWithTag("icon");
            TextView name = (TextView) cell.findViewWithTag("name");
            if (item.icon != null) {
                icon.setImageDrawable(item.icon);
            } else {
                icon.setImageDrawable(null);
            }
            name.setText(item.label);

            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(dp(12));
            if (position == selected) {
                bg.setColor(0x2200E5FF);
                bg.setStroke(dp(1) + 1, 0xFF29E7FF);
            } else {
                bg.setColor(0x0DFFFFFF);
                bg.setStroke(1, 0x1FFFFFFF);
            }
            cell.setBackgroundDrawable(bg);
            return cell;
        }
    }

    /* ---------------- 自绘控件 ---------------- */

    static class RingBadge extends View {
        private final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint arcPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint tickPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private long startTime = 0L;
        private float flyK = 0f;

        RingBadge(Context c) {
            super(c);
            setLayerType(LAYER_TYPE_SOFTWARE, null);
            ringPaint.setStyle(Paint.Style.STROKE);
            ringPaint.setStrokeWidth(dp(2));
            ringPaint.setColor(0x66FFFFFF);
            ringPaint.setShadowLayer(12f, 0, 0, 0xFF29E7FF);
            arcPaint.setStyle(Paint.Style.STROKE);
            arcPaint.setStrokeWidth(dp(3));
            arcPaint.setColor(0xFF29E7FF);
            arcPaint.setShadowLayer(14f, 0, 0, 0xFF29E7FF);
            tickPaint.setColor(0x99FFFFFF);
            tickPaint.setStrokeWidth(dp(2));
        }

        void start() {
            startTime = SystemClock.uptimeMillis();
            postInvalidateOnAnimation();
        }

        void fly() {
            flyK = 0.01f;
            postInvalidateOnAnimation();
        }

        private float dp(float v) {
            return v * getResources().getDisplayMetrics().density;
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float w = getWidth();
            float h = getHeight();
            float cx = w / 2f;
            float cy = h / 2f;
            float r = Math.min(w, h) / 2f - dp(6);
            long now = SystemClock.uptimeMillis();
            float t = (now - startTime) / 1000f;

            if (flyK > 0f) {
                flyK = Math.min(1f, flyK + 0.06f);
                r *= (1f - flyK * 0.35f);
                ringPaint.setAlpha((int) (255 * (1f - flyK)));
                arcPaint.setAlpha((int) (255 * (1f - flyK)));
                tickPaint.setAlpha((int) (255 * (1f - flyK)));
            }

            canvas.drawCircle(cx, cy, r, ringPaint);
            canvas.drawCircle(cx, cy, r * 0.86f, ringPaint);
            float rot = (t * 90f) % 360f;
            canvas.drawArc(new RectF(cx - r * 0.93f, cy - r * 0.93f, cx + r * 0.93f, cy + r * 0.93f),
                    rot, 70f, false, arcPaint);
            canvas.drawArc(new RectF(cx - r * 0.93f, cy - r * 0.93f, cx + r * 0.93f, cy + r * 0.93f),
                    rot + 180f, 40f, false, arcPaint);

            for (int i = 0; i < 24; i++) {
                double a = i * (Math.PI * 2 / 24);
                float r1 = r * 0.80f;
                float r2 = r * (i % 6 == 0 ? 0.70f : 0.75f);
                canvas.drawLine(cx + (float) Math.cos(a) * r1, cy + (float) Math.sin(a) * r1,
                        cx + (float) Math.cos(a) * r2, cy + (float) Math.sin(a) * r2, tickPaint);
            }

            if (flyK < 1f) {
                postInvalidateOnAnimation();
            }
        }
    }

    static class NeonText extends View {
        private String text = "";
        private int[] colors = new int[]{0xFF29E7FF};
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float sizePx = 48f;
        private long revealStart = 0L;
        private long revealMs = 0L;
        private boolean revealDone = true;
        private float letterGap = 1.06f;

        NeonText(Context c) {
            super(c);
            init();
        }

        NeonText(Context c, AttributeSet a) {
            super(c, a);
            init();
        }

        private void init() {
            setLayerType(LAYER_TYPE_SOFTWARE, null);
            paint.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
            paint.setTextAlign(Paint.Align.LEFT);
        }

        void setText(String t) {
            text = t == null ? "" : t;
            invalidate();
        }

        void setColors(int[] c) {
            if (c != null && c.length > 0) {
                colors = c;
            }
            invalidate();
        }

        void setTextSizePx(float s) {
            sizePx = s;
            invalidate();
        }

        void setLetterGap(float g) {
            letterGap = g;
        }

        void startReveal(long ms) {
            revealMs = Math.max(1L, ms);
            revealStart = SystemClock.uptimeMillis();
            revealDone = false;
            postInvalidateOnAnimation();
        }

        @Override
        protected void onMeasure(int wSpec, int hSpec) {
            int w = MeasureSpec.getSize(wSpec);
            int h = (int) (sizePx * 1.85f);
            setMeasuredDimension(resolveSize(w, wSpec), resolveSize(h, hSpec));
        }

        @Override
        protected void onDraw(Canvas canvas) {
            if (text.length() == 0) {
                return;
            }
            long now = SystemClock.uptimeMillis();
            float reveal = 1f;
            if (!revealDone) {
                reveal = (now - revealStart) / (float) revealMs;
                if (reveal >= 1f) {
                    reveal = 1f;
                    revealDone = true;
                }
            }
            float pulse = 0.55f + 0.45f * (float) Math.sin(now / 380.0);
            paint.setTextSize(sizePx);
            float totalW = 0f;
            for (int i = 0; i < text.length(); i++) {
                totalW += paint.measureText(text, i, i + 1) * letterGap;
            }
            float x = (getWidth() - totalW) / 2f;
            float baseY = getHeight() / 2f - (paint.descent() + paint.ascent()) / 2f;
            int n = text.length();
            for (int i = 0; i < n; i++) {
                float a = reveal * n - i;
                if (a <= 0f) {
                    break;
                }
                if (a > 1f) {
                    a = 1f;
                }
                int col = colors[i % colors.length];
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(col);
                paint.setAlpha((int) (255 * a));
                paint.setShadowLayer(8f + 16f * pulse, 0f, 0f, col);
                canvas.drawText(text, i, i + 1, x, baseY, paint);
                paint.clearShadowLayer();
                paint.setColor(0xFFFFFFFF);
                paint.setAlpha((int) (120 * a));
                canvas.drawText(text, i, i + 1, x, baseY, paint);
                x += paint.measureText(text, i, i + 1) * letterGap;
            }
            postInvalidateOnAnimation();
        }
    }

    static class GlowBackdrop extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final int[] blobColors = {0x5529E7FF, 0x55FF3FA7, 0x55B388FF};
        private final float[] phase = {0f, 2.1f, 4.2f};

        GlowBackdrop(Context c) {
            super(c);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            canvas.drawColor(0xFF05060A);
            long now = SystemClock.uptimeMillis();
            float t = now / 1000f;
            int w = getWidth();
            int h = getHeight();
            if (w == 0 || h == 0) {
                postInvalidateOnAnimation();
                return;
            }
            float minSide = Math.min(w, h);
            for (int i = 0; i < blobColors.length; i++) {
                float cx = w * (0.5f + 0.33f * (float) Math.sin(t * 0.35f + phase[i]));
                float cy = h * (0.45f + 0.28f * (float) Math.cos(t * 0.28f + phase[i] * 1.3f));
                float r = minSide * (0.45f + 0.08f * (float) Math.sin(t * 0.5f + i));
                if (r < 1f) {
                    continue;
                }
                paint.setShader(new RadialGradient(cx, cy, r, blobColors[i], 0x00000000, Shader.TileMode.CLAMP));
                canvas.drawCircle(cx, cy, r, paint);
            }
            paint.setShader(null);
            postInvalidateOnAnimation();
        }
    }

    static class LoadingBar extends View {
        private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private long start = 0L;
        private long dur = 1800L;

        LoadingBar(Context c) {
            super(c);
            setLayerType(LAYER_TYPE_SOFTWARE, null);
            track.setColor(0x22FFFFFF);
            fill.setColor(0xFF29E7FF);
        }

        void start(long ms) {
            dur = Math.max(200L, ms);
            start = SystemClock.uptimeMillis();
            postInvalidateOnAnimation();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float w = getWidth();
            float h = getHeight();
            if (w <= 0f || h <= 0f) {
                return;
            }
            float r = h / 2f;
            canvas.drawRoundRect(new RectF(0, 0, w, h), r, r, track);
            float k = dur <= 0 ? 1f : (SystemClock.uptimeMillis() - start) / (float) dur;
            if (k < 0f) {
                k = 0f;
            }
            if (k > 1f) {
                k = 1f;
            }
            float fw = Math.max(h, w * k);
            fill.setShader(new android.graphics.LinearGradient(0, 0, fw, 0,
                    new int[]{0xFF29E7FF, 0xFFB388FF, 0xFFFF3FA7},
                    new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
            fill.setShadowLayer(h * 1.6f, 0f, 0f, 0xFF29E7FF);
            canvas.drawRoundRect(new RectF(0, 0, fw, h), r, r, fill);
            fill.clearShadowLayer();
            if (k < 1f) {
                postInvalidateOnAnimation();
            }
        }
    }

    static class WarpTunnel extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private long start = 0L;
        private long dur = 950L;

        WarpTunnel(Context c) {
            super(c);
            setLayerType(LAYER_TYPE_SOFTWARE, null);
            paint.setStrokeWidth(3f);
        }

        void start(long ms) {
            dur = Math.max(200L, ms);
            start = SystemClock.uptimeMillis();
            postInvalidateOnAnimation();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            if (start == 0L) {
                return;
            }
            long now = SystemClock.uptimeMillis();
            float k = (now - start) / (float) dur;
            if (k < 0f) {
                k = 0f;
            }
            if (k > 1f) {
                k = 1f;
            }
            int w = getWidth();
            int h = getHeight();
            if (w == 0 || h == 0) {
                postInvalidateOnAnimation();
                return;
            }
            float cx = w / 2f;
            float cy = h / 2f;
            float maxR = (float) Math.hypot(w, h) / 2f;
            float alpha = (1f - k) * 255f;
            for (int i = 0; i < 76; i++) {
                double ang = i * (Math.PI * 2.0 / 76) + k * 0.25;
                float from = maxR * (0.04f + 0.55f * k * k);
                float to = maxR * (0.22f + 1.20f * k);
                paint.setColor(0xFF29E7FF);
                paint.setAlpha((int) (alpha * 0.7f));
                paint.setShadowLayer(12f, 0f, 0f, 0xFF7C4DFF);
                canvas.drawLine(cx + (float) Math.cos(ang) * from, cy + (float) Math.sin(ang) * from,
                        cx + (float) Math.cos(ang) * to, cy + (float) Math.sin(ang) * to, paint);
            }
            paint.clearShadowLayer();
            float flash = Math.max(0f, 1f - k * 1.7f);
            paint.setColor(0xFFFFFFFF);
            paint.setAlpha((int) (flash * 210f));
            canvas.drawCircle(cx, cy, maxR * 0.13f * flash + 6f, paint);
            if (k < 1f) {
                postInvalidateOnAnimation();
            }
        }
    }

}
