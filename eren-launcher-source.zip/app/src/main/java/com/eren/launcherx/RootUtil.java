package com.eren.launcherx;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/** 通过 su 执行命令；未授权时安静失败。 */
public class RootUtil {

    public static synchronized String run(String cmd) {
        try {
            Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", cmd});
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line;
            long end = System.currentTimeMillis() + 4000;
            while ((line = br.readLine()) != null && System.currentTimeMillis() < end) {
                sb.append(line).append('\n');
            }
            br.close();
            p.waitFor();
            return sb.toString().trim();
        } catch (Exception e) {
            return "";
        }
    }

    public static boolean available() {
        String out = run("id");
        return out.contains("uid=0");
    }
}
