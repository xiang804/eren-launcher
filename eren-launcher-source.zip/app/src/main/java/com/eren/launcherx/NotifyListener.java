package com.eren.launcherx;

import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.content.Intent;
import android.app.Notification;
import android.os.Bundle;

/** 把通知转发给悬浮助手做弹幕。 */
public class NotifyListener extends NotificationListenerService {

    public static final String ACTION_DANMAKU = "com.eren.launcherx.DANMAKU";

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            Notification n = sbn.getNotification();
            if (n == null) {
                return;
            }
            Bundle ex = n.extras;
            String title = ex == null ? "" : String.valueOf(ex.getCharSequence(Notification.EXTRA_TITLE));
            String text = ex == null ? "" : String.valueOf(ex.getCharSequence(Notification.EXTRA_TEXT));
            if (text == null || text.equals("null") || text.length() == 0) {
                return;
            }
            Intent i = new Intent(ACTION_DANMAKU);
            i.putExtra("title", title);
            i.putExtra("text", text);
            sendBroadcast(i);
        } catch (Exception ignored) {
        }
    }
}
